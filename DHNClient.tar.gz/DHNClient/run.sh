#!/bin/bash

var1=$(ps -ef | grep 'Dp=DHN_KHUG_Client_NM' | grep -v 'grep')

pid=$(echo ${var1} | cut -d " " -f2)

if [ -n "${pid}" ]
then
	echo "DHNClient_NM is running in the background"
else
	nohup ./jdk1.8/bin/java -Dp=DHN_KHUG_Client_NM -jar ./DHNClientKHUG-1.0.0.jar > /dev/null 2>&1 &
	echo "DHNClient_NM is start"
fi
