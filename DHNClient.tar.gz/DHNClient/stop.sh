#!/bin/bash

waitseconds=${1:-15}

var1=$(ps -ef | grep 'Dp=DHN_KHUG_Client_NM' | grep -v 'grep')

pid=$(echo ${var1} | cut -d " " -f2)
#### check process
if [ -z "$pid" ]; then
  echo "    Not Running! DHNClient_NM"
  exit 1
fi

#### stop normal
waitseconds=30
echo -e "\n    stop normal... (max wait: $waitseconds secconds, pid: $pid)"
printf "    "
while [ "$waitseconds" -gt 0 ]; do
  if [ -z `ps -ef | grep Dp=DHN_KHUG_Client_NM | grep -v grep | awk '{print $2}'` ]; then
    echo -e "\n${YELLOW}    stoped!"
    exit 0
  fi
  kill $pid
  printf "."; ((waitseconds--)); sleep 1
done

#### stop force
waitseconds=30
echo -e "\n    stop force... (max wait: $waitseconds secconds, pid: $pid)"
printf "    "
while [ "$waitseconds" -gt 0 ]; do
  if [ -z `ps -ef | grep Dp=DHN_KHUG_Client_NM | grep -v grep | awk '{print $2}'` ]; then
    echo -e "\n${RED}    stoped!"
    rm -rf pid
    exit 0
  fi
  kill -9 $pid
  printf "."; ((waitseconds--)); sleep 1
done
 
