#!/bin/bash

var1=$(ps -ef | grep 'Dp=DHN_Client' | grep -v 'grep')

pid=$(echo ${var1} | cut -d " " -f2)

if [ -n "${pid}" ]
then
	echo "DHNClient is running in the background"
else
	nohup ./jdk1.8/jre/bin/java -Dp=DHN_Client -jar ./DHNClient.jar > /dev/null 2>&1 &
	echo "DHNClient is start"
fi
